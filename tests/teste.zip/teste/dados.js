// Exemplo de criação de Dados:

const administrador = [
    {
        nome: "José",
        sobrenome: "Silva",
        email: "zesilva@gmail.com",
        senha: "qualqueruma"
    },
    {

    },
];

const usuario = [
    {
        nome: "Maria",
        sobrenome: "Silveira",
        email: "marsilveira@outlook.com",
        cpf: "12345678910",
        senha: 1234,
        telefone: "77988886666",
        foto: "maria.extensao"
    },
    {

    },
];

const categoria = [
    {
        nome: "livros"
    },
    {

    },
];

const publicacao = [
    {
        titulo: "Box de Livros Percy Jackson",
        tipo_negociacao: "venda",
        preco: 250,
        descricao_produto: "Coleção de livros da saga Percy Jackson e os Olimpianos em bom estado de conservação. Acompanha marcadores de livro da franquia também.",
        descricao_vendedor: "Sou colecionadora de várias franquias literárias e gosto de fazer bons negócios com os livros mais antigos que tenho ou compro de outros colecionadores. Faço envios para todo o país e meu contato é (77) 98888-6666"
    },
    {

    },
]

const fotos = [
    {
        foto1: "nomedoarquivo.extensao",
        foto2: "nomedoarquivo.extensao",
        foto3: "nomedoarquivo.extensao",
        foto4: "nomedoarquivo.extensao"
    },
    {
        
    }
];

/*obs.:
- os exemplos devem estar conectados uns com os outros e fazer sentido
como se fossem dados reais.
- anexar as imagens usadas nos exemplos.*/